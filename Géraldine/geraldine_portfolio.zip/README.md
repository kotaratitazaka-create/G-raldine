# Portfolio Géraldine

Ce dossier contient la version locale du portfolio actualisée à partir des informations contenues dans les CV fournis.

- Page principale : index.html
- Les contenus ont été alignés sur les données officielles extraites des documents Word du dossier fourni.
